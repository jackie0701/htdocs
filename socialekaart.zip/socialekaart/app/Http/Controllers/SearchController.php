<?php

namespace App\Http\Controllers;


use http\Env\Request;
use Illuminate\Support\Facades\DB;
use SocialeKaart\Organisatie;

class SearchController extends Controller
{
    public function filter()
    {
        $organisaties = DB::table('leefgebied')->select('leefgebied', 'organisaties.organisatie_id', 'organisaties.naam', 'organisaties.adres',
            'organisaties.contactpersoon', 'organisaties.gemeente', 'organisaties.telefoonnummer', 'organisaties.beschrijving')
            ->from('organisaties')
            ->join('problematiek', 'problematiek.organisatie_id', '=', 'organisaties.organisatie_id')
            ->join('thema', 'thema.thema_id', '=', 'problematiek.thema_id')
            ->join('koppel_thema_leef', 'koppel_thema_leef.thema_id', '=', 'thema.thema_id')
            ->join('leefgebied', 'leefgebied.leefgebied_id', '=', 'koppel_thema_leef.leefgebied_id')
            ->whereIn('problematiek.thema_id', [1, 6])
            ->where('organisaties.gemeente', 'katwijk')
            ->orderBy('naam', 'asc')
            ->distinct()->paginate(7);

        return response($organisaties, compact('organisaties'));
    }
}
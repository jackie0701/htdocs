<?php

namespace SocialeKaart;

use Illuminate\Database\Eloquent\Model;

class Organisatie extends Model
{
    protected $table = 'gemeente';

    public $primaryKey = 'organisatie_id';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'organisatie_id','naam', 'adres', 'contactpersoon', 'gemeente', 'telefoonnummer', 'beschrijving'
    ];

    public function filter(){

        return $this->belongsToMany('gemeente', 'organisaties');
    }
}

<?php

namespace SocialeKaart;

use Illuminate\Database\Eloquent\Model;

class Gemeente extends Model
{
    //
}

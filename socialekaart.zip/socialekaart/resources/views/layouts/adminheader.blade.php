@include('includes.header')
<body>
<header id="app">
@include('includes.navbar-admin')
</header>
<nav class="sidebar toggled">
    <div class="sidebar-wrapper bg-dark">
        <ul class="sidebar-nav">
            <li>
                <a class="nav-link" href="{{ url('/account') }}">Home</a>
            </li>
            <li>
                <a class="nav-link" href="{{url('/gebruiker')}}">Gebruikers</a>
            </li>
        </ul>
    </div>
</nav>
@yield('content')
</body>
</html>
@extends ('layouts.adminheader')

@section('content')
    <h1>test</h1>
@endsection
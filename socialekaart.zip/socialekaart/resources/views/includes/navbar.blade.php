<div class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="navbar-brand">
        <a href="{{ url('/') }}" class="link">OnsPlatform</a>
    </div>
    <ul class="navbar-nav mr-auto">
    </ul>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            @if (Route::has('login'))
            <div class="top-right">
                @auth
                <a href="{{ url('/account') }}" class="link">Account</a>
                <a href="{{ route('logout') }}"
                   onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();" class="link">
                    {{ __('Logout') }}
                </a>
                @else
                @endauth
            </div>
            @endif
        </li>
        <li class="nav-item">
            @if (Route::has('logout'))
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                @csrf
            </form>
            @endif
        </li>
    </ul>

</div>

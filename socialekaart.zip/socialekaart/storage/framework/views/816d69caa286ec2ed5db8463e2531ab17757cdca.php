<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="default">
<header id="app">
    <?php echo $__env->make('includes.navbar-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</header>
<nav class="sidebar toggled">
    <div class="sidebar-wrapper bg-dark">
        <ul class="sidebar-nav">
            <li>
                <a class="nav-link" href="<?php echo e(url('/account')); ?>">Home</a>
            </li>
            <li>
                <a class="nav-link" href="<?php echo e(url('gebruiker')); ?>">Gebruikers</a>
            </li>
        </ul>
    </div>
</nav>


<main class="py-4 px-4">
    <?php echo $__env->yieldContent('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card text-black bg-white">
                    <div class="card-header">
                        Welkom, <?php echo e(ucfirst(Auth::user()->name)); ?>

                    </div>
                    <div class="card-body">
                        Dit is de admin panel.
                    </div>
                </div>
            </div>
        </div>
    </div>

</main>

<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>

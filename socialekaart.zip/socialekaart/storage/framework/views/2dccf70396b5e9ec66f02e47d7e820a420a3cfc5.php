<div class="default">

<?php $__env->startSection('content'); ?>
    <main class="py-4 px-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <table class="table">
                            <thead>
                            <th scope="col">id:</th>
                            <th scope="cole">naam:</th>
                            <th scope="col">email</th>
                            </thead>
                            <?php $__currentLoopData = $gebruikers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gebruiker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                <td><?php echo e($gebruiker->id); ?></td>
                                <td><?php echo e($gebruiker->name); ?></td>
                                <td><?php echo e($gebruiker->email); ?></td>
                                <td><a class="btn btn-info" href="<?php echo e(route('gebruiker.edit',$gebruiker->id)); ?>">edit</a>
                                </td>
                                <form action="<?php echo e(url('/gebruiker/' . $gebruiker->id . '/delete')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo e(method_field('DELETE')); ?>


                                    <td>
                                        <button type="submit" id="delete-gebruiker-<?php echo e($gebruiker->id); ?>"
                                                class="btn btn-danger">
                                            <i class="fa fa-btn fa-trash"></i>Delete
                                        </button>
                                    </td>
                                </form>
                                </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <table class="table">
                            <tbody>
                            <th>Create user</th>
                            <td>
                                <a class="btn btn-info" href="<?php echo e(url('gebruiker/add')); ?>">add</a>
                            </td>
                            </tbody>
                            </form>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adminheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8"/>
    <meta name="description" content="Start | Sociale Kaart"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Start'); ?> | Sociale kaart</title>
    <?php $__env->startSection('styles'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset("../css/socialekaart.css")); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset("../css/sidebar.css")); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset("../css/bootstrap.css")); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset("../css/app.css")); ?>">
        <script type="text/javascript" src="<?php echo e(asset('../js/app.js')); ?>"></script>
    <?php echo $__env->yieldSection(); ?>
</head>
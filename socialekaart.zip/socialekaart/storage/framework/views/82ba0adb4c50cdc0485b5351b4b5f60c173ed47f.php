<div class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="navbar-brand">
        <a href="<?php echo e(url('/')); ?>" class="link">OnsPlatform</a>
    </div>
    <ul class="navbar-nav mr-auto">
    </ul>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <?php if(Route::has('login')): ?>
            <div class="top-right">
                <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/account')); ?>" class="link">Account</a>
                <a href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();" class="link">
                    <?php echo e(__('Logout')); ?>

                </a>
                <?php else: ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </li>
        <li class="nav-item">
            <?php if(Route::has('logout')): ?>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            <?php endif; ?>
        </li>
    </ul>

</div>

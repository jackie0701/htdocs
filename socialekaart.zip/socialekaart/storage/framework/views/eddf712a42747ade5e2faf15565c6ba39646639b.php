<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8"/>
    <meta name="description" content="Sociale Kaart"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Instantienaam'); ?> | Sociale kaart</title>
    <?php $__env->startSection('styles'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset("../css/sidebar.css")); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset("../css/bootstrap.css")); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset("../css/app.css")); ?>">
        <script type="text/javascript" src="<?php echo e(URL::asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldSection(); ?>
</head>
<div class="default">
    <?php echo $__env->make('includes.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="jumbotron">
        <div class="container" style="margin-top:80px;">
            <h1 class="display-4">OnsPlaform</h1>
            <p>This is a template for a simple marketing or informational website. It includes a large callout called a
                jumbotron and three supporting pieces of content. Use it as a starting point to create something more
                unique.</p>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <!-- BEGIN SEARCH RESULT -->
            <div class="col-md-12">
                <div class="grid search">
                    <div class="grid-body">
                        <div class="row">
                            <div class="col-md-9">
                                <nav aria-label="breadcrumb">

                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="/">Start</a></li>
                                        <li class="breadcrumb-item"><a href="/werk">Werk</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">
                                            <?php echo e($organisaties->naam); ?></li>
                                    </ol>
                                </nav>
                                <hr>
                                <div class=" card__title">
                                    <h2>Instantie details</h2>
                                </div>
                                <br>
                                <div class="row table-row">
                                    <!-- details -->
                                    <div class="col-xs-6 col-sm-6">
                                        Bedrijfsnaam
                                    </div>
                                    <div class="col-xs-6 col-sm-6">
                                        <?php echo e($organisaties->naam); ?>

                                    </div>
                                </div>
                                <div class="row table-row">
                                    <!-- details -->
                                    <div class="col-xs-6 col-sm-6">
                                        Bedrijfsnaam ID
                                    </div>
                                    <div class="col-xs-6 col-sm-6">
                                    </div>
                                </div>
                                <div class="row table-row">
                                    <!-- details -->
                                    <div class="col-xs-6 col-sm-6">
                                        Adres
                                    </div>
                                    <div class="col-xs-6 col-sm-6">
                                        <?php echo e($organisaties->naam); ?><br>
                                        <?php echo e($organisaties->adres); ?>

                                    </div>
                                </div>
                                <div class="row table-row">
                                    <!-- details -->
                                    <div class="col-xs-6 col-sm-6">
                                        Contactpersoon
                                    </div>
                                    <div class="col-xs-6 col-sm-6">
                                        <?php echo e($organisaties->contactpersoon); ?>

                                    </div>
                                </div>
                                <div class="row table-row">
                                    <!-- details -->
                                    <div class="col-xs-6 col-sm-6">
                                        Gemeente
                                    </div>
                                    <div class="col-xs-6 col-sm-6">
                                        <?php echo e($organisaties->gemeente); ?>

                                    </div>
                                </div>
                                <div class="row table-row">
                                    <!-- details -->
                                    <div class="col-xs-6 col-sm-6">
                                        Telefoonnummer
                                    </div>
                                    <div class="col-xs-6 col-sm-6">
                                        <?php echo e($organisaties->telefoonnummer); ?>

                                    </div>
                                </div>
                                <br>
                                <div class="row table-row">
                                    <!-- details -->
                                    <div class="col-xs-6 col-sm-6">
                                        Over <?php echo e($organisaties->naam); ?>

                                    </div>
                                    <div class="col-xs-6 col-sm-6">
                                        <?php echo e($organisaties->beschrijving); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    </body>
</html>


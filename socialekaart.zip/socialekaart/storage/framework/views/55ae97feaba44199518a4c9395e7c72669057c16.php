<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<header id="app">
<?php echo $__env->make('includes.navbar-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</header>
<nav class="sidebar toggled">
    <div class="sidebar-wrapper bg-dark">
        <ul class="sidebar-nav">
            <li>
                <a class="nav-link" href="<?php echo e(url('/account')); ?>">Home</a>
            </li>
            <li>
                <a class="nav-link" href="<?php echo e(url('/gebruiker')); ?>">Gebruikers</a>
            </li>
        </ul>
    </div>
</nav>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
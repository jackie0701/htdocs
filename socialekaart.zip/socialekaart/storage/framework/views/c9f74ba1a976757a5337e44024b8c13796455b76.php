<?php $__env->startSection('content'); ?>

    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <form action="<?php echo e(route('gebruiker.update',$gebruiker->id)); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Name:</strong>
                                     <input type="text" name="name" value="<?php echo e($gebruiker->name); ?>" class="form-control" placeholder="Name">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12">
                                <div class="form-group">
                                    <strong>Email:</strong>
                                    <input type="text" class="form-control" name="email" placeholder="Detail" value="<?php echo e($gebruiker->email); ?>">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                </form>
            </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>